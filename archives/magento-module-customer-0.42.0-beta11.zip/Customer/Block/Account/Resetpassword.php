<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Customer\Block\Account;

/**
 * Customer reset password form
 */
class Resetpassword extends \Magento\Framework\View\Element\Template
{
}
