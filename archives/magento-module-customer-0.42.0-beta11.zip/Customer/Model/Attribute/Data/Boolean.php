<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Customer Attribute Boolean Data Model
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Magento\Customer\Model\Attribute\Data;

class Boolean extends \Magento\Eav\Model\Attribute\Data\Boolean
{
}
